package com.test.model;
import java.sql.Date;
public class TestproductVO {
	private String pcode;
	private String pname;
	private String pinfo;
	private String pprice;
	private String pid;
	private String pstar;
	
	public String getPcode() { return pcode; }
	public void setPcode(String pcode) { this.pcode = pcode; }
	
	public String getPname() { return pname; }
	public void setPname(String pname) { this.pname = pname; }
	
	public String getPinfo() { return pinfo; }
	public void setPinfo(String pinfo) { this.pinfo = pinfo; }
	
	public String getPprice() {	return pprice; }
	public void setPprice(String pprice) { this.pprice = pprice; }
	
	public String getPid() { return pid; }
	public void setPid(String pid) { this.pid = pid; }
	
	public String getPstar() { return pstar; }
	public void setPstar(String pstar) { this.pstar = pstar; }
		
}
